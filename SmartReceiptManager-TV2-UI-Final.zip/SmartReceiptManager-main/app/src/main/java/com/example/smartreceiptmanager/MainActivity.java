package com.example.smartreceiptmanager;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private TextView txtTotal, txtCount, txtEmpty;
    private ListView listExpense;
    private ExpenseAdapter adapter;
    private ArrayList<Expense> expenses;
    private final NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(new Locale("vi", "VN"));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        txtTotal = findViewById(R.id.txtTotal);
        txtCount = findViewById(R.id.txtCount);
        txtEmpty = findViewById(R.id.txtEmpty);
        listExpense = findViewById(R.id.listExpense);
        Button btnAddExpense = findViewById(R.id.btnAddExpense);
        Button btnScan = findViewById(R.id.btnScan);

        btnAddExpense.setOnClickListener(v -> startActivity(new Intent(this, AddExpenseActivity.class)));
        btnScan.setOnClickListener(v -> Toast.makeText(this, "Chức năng quét hóa đơn sẽ được tích hợp ở module OCR", Toast.LENGTH_SHORT).show());

        listExpense.setOnItemClickListener((parent, view, position, id) -> {
            Expense expense = (Expense) adapter.getItem(position);
            Intent intent = new Intent(this, AddExpenseActivity.class);
            intent.putExtra("expense_id", expense.getId());
            startActivity(intent);
        });

        listExpense.setOnItemLongClickListener((parent, view, position, id) -> {
            Expense expense = (Expense) adapter.getItem(position);
            showDeleteDialog(expense);
            return true;
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadExpenses();
    }

    private void loadExpenses() {
        expenses = ExpenseRepository.getAll();
        adapter = new ExpenseAdapter(this, expenses);
        listExpense.setAdapter(adapter);
        txtTotal.setText(currencyFormat.format(ExpenseRepository.getTotalAmount()));
        txtCount.setText(expenses.size() + " khoản chi");
        txtEmpty.setVisibility(expenses.isEmpty() ? android.view.View.VISIBLE : android.view.View.GONE);
    }

    private void showDeleteDialog(Expense expense) {
        new AlertDialog.Builder(this)
                .setTitle("Xóa khoản chi")
                .setMessage("Bạn có chắc muốn xóa \"" + expense.getTitle() + "\" không?")
                .setNegativeButton("Hủy", null)
                .setPositiveButton("Xóa", (dialog, which) -> {
                    ExpenseRepository.delete(expense.getId());
                    loadExpenses();
                    Toast.makeText(this, "Đã xóa khoản chi", Toast.LENGTH_SHORT).show();
                })
                .show();
    }
}
