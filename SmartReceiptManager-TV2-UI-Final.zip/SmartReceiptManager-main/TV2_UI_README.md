# TV2 - UI quản lý khoản chi

Phần UI đã hoàn thiện cho module TV2 trong đồ án Smart Receipt Manager.

## File Java đã thêm/sửa
- `MainActivity.java`: Home dashboard, tổng chi tiêu, danh sách khoản chi, nút thêm/quét hóa đơn.
- `AddExpenseActivity.java`: Form thêm/sửa/xóa khoản chi.
- `Expense.java`: Model khoản chi.
- `ExpenseAdapter.java`: Adapter hiển thị từng item khoản chi.
- `ExpenseRepository.java`: Dữ liệu demo và xử lý CRUD tạm thời.

## File layout đã thêm/sửa
- `activity_main.xml`: UI trang chủ TV2.
- `activity_add_expense.xml`: UI form thêm/sửa khoản chi.
- `item_expense.xml`: UI item khoản chi.

## File style/drawable đã thêm
- `colors.xml`: Màu chủ đạo xanh dương, nền xám nhạt, danger đỏ.
- `styles.xml`: Style chung cho label và input.
- `bg_button_primary.xml`
- `bg_button_danger.xml`
- `bg_button_gray.xml`
- `bg_button_outline.xml`
- `bg_input.xml`
- `bg_card.xml`
- `bg_circle_primary.xml`
- `bg_circle_soft.xml`

## Chức năng UI
- Xem tổng chi tiêu.
- Xem danh sách khoản chi gần đây.
- Thêm khoản chi.
- Sửa khoản chi bằng cách nhấn vào item.
- Xóa khoản chi bằng nút xóa trong màn hình sửa hoặc nhấn giữ item.
- UI thống nhất: xanh dương, nền trắng/xám nhạt, title 20-22sp, body 14-16sp, nút xóa màu đỏ cảnh báo.
